package com.example.coffee.entity;

import jakarta.persistence.*;
import com.google.gson.Gson;
import lombok.Data;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;

@Data
@Entity
@Table(name = "MachineTemperature")
public class MachineTemperature {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "temp_id")
    private Long tempId;

    @Column(name = "temperature", nullable = false)
    private double temperature;

    @Column(name = "recorded_at", nullable = false)
    private String recordedAt;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "coffee_machine_id", nullable = false)
    private CoffeeMachine coffeeMachine;

    @Transient
    private Long coffeeMachineId;

    @Transient
    private String type;

    public String serialize() {
        return new Gson().toJson(this);
    }
    public Long getTempId() {
        return tempId;
    }
    public void setTempId(Long tempId) {
        this.tempId = tempId;
    }
    public double getTemperature() {
        return temperature;
    }
    public void setTemperature(double temperature) {
        this.temperature = temperature;
    }
    public String getRecordedAt() {
        return recordedAt;
    }
    public void setRecordedAt(String recordedAt) {
        this.recordedAt = recordedAt;
    }
    public CoffeeMachine getCoffeeMachine() {
        return coffeeMachine;
    }
    public void setCoffeeMachine(CoffeeMachine coffeeMachine) {
        this.coffeeMachine = coffeeMachine;
    }
    public Long getCoffeeMachineId() {
        return coffeeMachine != null ? coffeeMachine.getCoffeeMachineId() : coffeeMachineId;
    }
    public void setCoffeeMachineId(Long coffeeMachineId) {
        this.coffeeMachineId = coffeeMachineId;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public MachineTemperature() {
    }
    public MachineTemperature(Long tempId, double temperature, String recordedAt, CoffeeMachine coffeeMachine) {
        this.tempId = tempId;
        this.temperature = temperature;
        this.recordedAt = recordedAt;
        this.coffeeMachine = coffeeMachine;
    }

}

package com.example.coffee.entity;

import jakarta.persistence.*;
import com.google.gson.Gson;
import lombok.Data;
import com.fasterxml.jackson.annotation.JsonBackReference;
import java.util.List;

@Data
@Entity
@Table(name = "coffee_ingredients")  // Changed table name to match SQL convention
public class CoffeeIngredients {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "coffee_ingredient_id")
    private Long coffeeIngredientId;

    @Column(name = "sugar_level", nullable = false)
    private String sugarLevel;

    @Column(name = "milk_level", nullable = false)
    private String milkLevel;

    @Column(name = "coffee_powder", nullable = false)
    private String coffeePowder;

    @Column(name = "tea_powder", nullable = false)
    private String teaPowder;

    @Column(name = "water_level", nullable = false)
    private String waterLevel;

    @Column(name = "recorded_at", nullable = false)
    private String recordedAt;
    
    @Column(name = "type", nullable = false)  // Changed from Transient to Column
    private String type = "2";  // Default type for ingredients

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "coffee_machine_id", nullable = false)
    private CoffeeMachine coffeeMachine;

    public String serialize() {
        return new Gson().toJson(this);
    }

    public Long getCoffeeIngredientId() {
        return coffeeIngredientId;
    }
    public void setCoffeeIngredientId(Long coffeeIngredientId) {
        this.coffeeIngredientId = coffeeIngredientId;
    }
    public String getSugarLevel() {
        return sugarLevel;
    }
    public void setSugarLevel(String sugarLevel) {
        this.sugarLevel = sugarLevel;
    }
    public String getMilkLevel() {
        return milkLevel;
    }
    public void setMilkLevel(String milkLevel) {
        this.milkLevel = milkLevel;
    }
    public String getCoffeePowder() {
        return coffeePowder;
    }
    public void setCoffeePowder(String coffeePowder) {
        this.coffeePowder = coffeePowder;
    }
    public String getTeaPowder() {
        return teaPowder;
    }
    public void setTeaPowder(String teaPowder) {
        this.teaPowder = teaPowder;
    }
    public String getWaterLevel() {
        return waterLevel;
    }
    public void setWaterLevel(String waterLevel) {
        this.waterLevel = waterLevel;
    }
    public String getRecordedAt() {
        return recordedAt;
    }
    public void setRecordedAt(String recordedAt) {
        this.recordedAt = recordedAt;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public CoffeeMachine getCoffeeMachine() {
        return coffeeMachine;
    }
    public void setCoffeeMachine(CoffeeMachine coffeeMachine) {
        this.coffeeMachine = coffeeMachine;
    }
    public CoffeeIngredients() {
        this.type = "2";  // Set default type in constructor
    }
    public CoffeeIngredients(Long coffeeIngredientId, String sugarLevel, String milkLevel, String coffeePowder, String teaPowder, String waterLevel, String recordedAt, String type) {
        this.coffeeIngredientId = coffeeIngredientId;
        this.sugarLevel = sugarLevel;
        this.milkLevel = milkLevel;
        this.coffeePowder = coffeePowder;
        this.teaPowder = teaPowder;
        this.waterLevel = waterLevel;
        this.recordedAt = recordedAt;
        this.type = type;
    }
    
}

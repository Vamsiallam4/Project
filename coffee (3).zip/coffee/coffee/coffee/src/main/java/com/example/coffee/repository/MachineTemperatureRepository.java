package com.example.coffee.repository;

import com.example.coffee.entity.MachineTemperature;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

@Repository
public interface MachineTemperatureRepository extends JpaRepository<MachineTemperature, Long> {
    @Query("SELECT t FROM MachineTemperature t WHERE t.coffeeMachine.coffeeMachineId = :coffeeMachineId")
    List<MachineTemperature> findByCoffeeMachineId(@Param("coffeeMachineId") Long coffeeMachineId);
}

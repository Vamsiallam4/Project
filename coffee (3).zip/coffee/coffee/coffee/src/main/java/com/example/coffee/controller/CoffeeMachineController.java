package com.example.coffee.controller;

import com.example.coffee.entity.CoffeeMachine;
import com.example.coffee.service.CoffeeMachineService;
import com.example.coffee.dto.CoffeeMachineDTO;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.annotation.PostConstruct;
import java.util.Map;

@RestController
@RequestMapping("/api/coffee-machines")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class CoffeeMachineController {

    @Autowired
    private CoffeeMachineService coffeeMachineService;

    @Autowired
    private ObjectMapper objectMapper;

    @PostConstruct
    public void setup() {
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> createCoffeeMachine(@RequestBody CoffeeMachineDTO dto) {
        try {
            CoffeeMachine machine = coffeeMachineService.createCoffeeMachine(dto);
            return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_JSON)
                .body(machine);
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(Map.of("error", "Invalid request format: " + e.getMessage()));
        }
    }

    @PutMapping("/{id}/toggle-status")
    public ResponseEntity<CoffeeMachine> toggleStatus(@PathVariable("id") Long coffeeMachineId) {
        return ResponseEntity.ok(coffeeMachineService.toggleStatus(coffeeMachineId));
    }
}
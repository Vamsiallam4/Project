package com.example.coffee.service;

import com.example.coffee.entity.Location;
import com.example.coffee.repository.LocationRepository;
import com.example.coffee.dto.LocationDTO;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class LocationService {

    @Autowired
    private LocationRepository locationRepository;

    public Location createLocation(LocationDTO dto) {
        if (locationRepository.existsByName(dto.getName())) {
            throw new RuntimeException("Location with this name already exists");
        }
        Location location = new Location();
        location.setName(dto.getName());
        return locationRepository.save(location);
    }

    public List<Location> getAllLocations() {
        return locationRepository.findAll();
    }

    public Location getLocation(Long id) {
        return locationRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Location not found"));
    }

    public Location updateLocation(Long id, LocationDTO locationDTO) {
        Location existingLocation = locationRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Location not found"));
        BeanUtils.copyProperties(locationDTO, existingLocation, "id");
        return locationRepository.save(existingLocation);
    }

    public void deleteLocation(Long id) {
        locationRepository.deleteById(id);
    }
}

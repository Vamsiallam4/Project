package com.example.coffee.dto;

public class MachineTemperatureDTO {
    private Long tempId;
    private double temperature;
    private String recordedAt;
    private Long coffeeMachineId;  // Add this field
    private String type;

    public MachineTemperatureDTO() {
    }
    public MachineTemperatureDTO(Long tempId, double temperature, String recordedAt) {
        this.tempId = tempId;
        this.temperature = temperature;
        this.recordedAt = recordedAt;
    }
    public Long getTempId() {
        return tempId;
    }
    public void setTempId(Long tempId) {
        this.tempId = tempId;
    }
    public double getTemperature() {
        return temperature;
    }
    public void setTemperature(double temperature) {
        this.temperature = temperature;
    }
    public String getRecordedAt() {
        return recordedAt;
    }
    public void setRecordedAt(String recordedAt) {
        this.recordedAt = recordedAt;
    }
    public Long getCoffeeMachineId() {
        return coffeeMachineId;
    }
    public void setCoffeeMachineId(Long coffeeMachineId) {
        this.coffeeMachineId = coffeeMachineId;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
}

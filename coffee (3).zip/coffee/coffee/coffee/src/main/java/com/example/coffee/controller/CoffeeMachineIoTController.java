package com.example.coffee.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.coffee.entity.MachineTemperature;
import com.example.coffee.dto.CoffeeIngredientsDTO;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.sdk.iot.device.*;
import com.microsoft.azure.sdk.iot.device.exceptions.IotHubClientException;
import org.json.JSONObject;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/api/iot")
public class CoffeeMachineIoTController {
    private String connStringTemp = "HostName=cofffe-hub.azure-devices.net;DeviceId=tempdev;SharedAccessKey=diFjjHXGsrh6/35n4aC7ebO808Demy/vYmcSr0dFPVY=";
    private String connStringIngredients = "HostName=cofffe-hub.azure-devices.net;DeviceId=ingredev;SharedAccessKey=IUojK5OKiW4IuFVVKwLWPB7euTlrRb/sMDFo5XIR8Lc=";
    private static IotHubClientProtocol protocol = IotHubClientProtocol.MQTT;
    private ObjectMapper objectMapper = new ObjectMapper();

    private static class EventCallback implements MessageSentCallback {
        private String status;
        @Override
        public void onMessageSent(Message sentMessage, IotHubClientException exception, Object callbackContext) {
            status = (exception == null ? IotHubStatusCode.OK.toString() : exception.getStatusCode().toString());
            System.out.println("IoT Hub responded to message with status: " + status);
            if (callbackContext != null) {
                synchronized (callbackContext) {
                    callbackContext.notify();
                }
            }
        }
        public String getStatus() {
            return status;
        }
    }

    @PostMapping("/temperature")
    public ResponseEntity<?> sendTemperature(@RequestBody MachineTemperature dto) {
        try {
            DeviceClient client = null;
            try {
                client = new DeviceClient(connStringTemp, protocol);
                client.open(true);

                dto.setType("1"); // Add type field
                String msgStr = objectMapper.writeValueAsString(dto);
                Message msg = new Message(msgStr);
                msg.setProperty("type", "1");
                System.out.println("Sending temperature data: " + msgStr);

                Object lockobj = new Object();
                EventCallback callback = new EventCallback();
                client.sendEventAsync(msg, callback, lockobj);

                synchronized (lockobj) {
                    lockobj.wait(5000);
                }

                String status = callback.getStatus();
                if (status == null) {
                    return ResponseEntity.status(500).body("Timeout waiting for IoT Hub response");
                }
                return ResponseEntity.ok("Temperature data sent successfully: " + status);
            } finally {
                if (client != null) {
                    client.close();
                }
            }
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error sending temperature data: " + e.getMessage());
        }
    }

    @PostMapping("/ingredients")
    public ResponseEntity<?> sendIngredients(@RequestBody CoffeeIngredientsDTO dto) {
        try {
            DeviceClient client = null;
            try {
                client = new DeviceClient(connStringIngredients, protocol);
                client.open(true);

                dto.setType("2"); // Set type for ingredients
                String msgStr = objectMapper.writeValueAsString(dto);
                Message msg = new Message(msgStr);
                msg.setProperty("type", "2");

                System.out.println("Sending ingredients data: " + msgStr);
                Object lockobj = new Object();
                EventCallback callback = new EventCallback();
                client.sendEventAsync(msg, callback, lockobj);

                synchronized (lockobj) {
                    lockobj.wait(5000);
                }

                String status = callback.getStatus();
                if (status == null) {
                    return ResponseEntity.status(500).body("Timeout waiting for IoT Hub response");
                }
                return ResponseEntity.ok("Ingredients data sent successfully: " + status);
            } finally {
                if (client != null) {
                    client.close();
                }
            }
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error sending ingredients data: " + e.getMessage());
        }
    }
}

package com.example.coffee.service;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.coffee.entity.CoffeeIngredients;
import com.example.coffee.dto.CoffeeIngredientsDTO;
import com.example.coffee.repository.CoffeeIngredientsRepository;

@Service
public class CoffeeIngredientsService {
    @Autowired
    private CoffeeIngredientsRepository coffeeIngredientsRepository;

    public CoffeeIngredientsDTO saveCoffeeIngredients(CoffeeIngredientsDTO dto) {
        CoffeeIngredients entity = convertToEntity(dto);
        entity = coffeeIngredientsRepository.save(entity);
        return convertToDTO(entity);
    }

    public List<CoffeeIngredientsDTO> getAllCoffeeIngredients() {
        return coffeeIngredientsRepository.findAll()
            .stream()
            .map(this::convertToDTO)
            .collect(Collectors.toList());
    }

    public List<CoffeeIngredientsDTO> getIngredientsByMachineId(Long coffeeMachineId) {
        return coffeeIngredientsRepository.findByCoffeeMachineId(coffeeMachineId)
            .stream()
            .map(this::convertToDTO)
            .collect(Collectors.toList());
    }

    private CoffeeIngredients convertToEntity(CoffeeIngredientsDTO dto) {
        CoffeeIngredients entity = new CoffeeIngredients();
        BeanUtils.copyProperties(dto, entity);
        return entity;
    }

    private CoffeeIngredientsDTO convertToDTO(CoffeeIngredients entity) {
        CoffeeIngredientsDTO dto = new CoffeeIngredientsDTO();
        BeanUtils.copyProperties(entity, dto);
        return dto;
    }
}

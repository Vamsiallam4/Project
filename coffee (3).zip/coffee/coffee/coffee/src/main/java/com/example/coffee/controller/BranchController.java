package com.example.coffee.controller;

import com.example.coffee.dto.BranchDTO;
import com.example.coffee.entity.Branch;
import com.example.coffee.service.BranchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/branches")
@CrossOrigin(origins = "*", allowedHeaders = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE, RequestMethod.OPTIONS})
public class BranchController {
    @Autowired
    private BranchService branchService;

    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Branch> createBranch(@RequestBody BranchDTO branchDTO) {
        try {
            Branch branch = branchService.createBranch(branchDTO);
            return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_JSON)
                .body(branch);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("/location/{locationId}")
    public ResponseEntity<List<Branch>> getBranchesByLocation(@PathVariable("locationId") Long locationId) {
        return ResponseEntity.ok(branchService.getBranchesByLocation(locationId));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Branch> getBranch(@PathVariable("id") Long id) {
        return ResponseEntity.ok(branchService.getBranch(id));
    }
}

package com.example.coffee.repository;

import com.example.coffee.entity.CoffeeMachine;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface CoffeeMachineRepository extends JpaRepository<CoffeeMachine, Long> {
    List<CoffeeMachine> findByBranchId(Long branchId);
    List<CoffeeMachine> findByBranchLocationId(Long locationId);
}

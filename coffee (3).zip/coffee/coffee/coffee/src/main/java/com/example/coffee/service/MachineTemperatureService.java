package com.example.coffee.service;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.coffee.entity.MachineTemperature;
import com.example.coffee.dto.MachineTemperatureDTO;
import com.example.coffee.repository.MachineTemperatureRepository;
import com.example.coffee.service.CoffeeMachineService;

@Service
public class MachineTemperatureService {
    @Autowired
    private MachineTemperatureRepository machineTemperatureRepository;

    @Autowired
    private CoffeeMachineService coffeeMachineService;

    public MachineTemperatureDTO saveMachineTemperature(MachineTemperatureDTO dto) {
        MachineTemperature entity = convertToEntity(dto);
        entity = machineTemperatureRepository.save(entity);
        return convertToDTO(entity);
    }

    public List<MachineTemperatureDTO> getAllMachineTemperatures() {
        return machineTemperatureRepository.findAll()
            .stream()
            .map(this::convertToDTO)
            .collect(Collectors.toList());
    }

    public List<MachineTemperatureDTO> getTemperaturesByMachineId(Long coffeeMachineId) {
        return machineTemperatureRepository.findByCoffeeMachineId(coffeeMachineId)
            .stream()
            .map(this::convertToDTO)
            .collect(Collectors.toList());
    }

    private MachineTemperature convertToEntity(MachineTemperatureDTO dto) {
        MachineTemperature entity = new MachineTemperature();
        entity.setTempId(dto.getTempId());
        entity.setTemperature(dto.getTemperature());
        entity.setRecordedAt(dto.getRecordedAt());
        if (dto.getCoffeeMachineId() != null) {
            entity.setCoffeeMachine(coffeeMachineService.getCoffeeMachine(dto.getCoffeeMachineId()));
        }
        return entity;
    }

    private MachineTemperatureDTO convertToDTO(MachineTemperature entity) {
        MachineTemperatureDTO dto = new MachineTemperatureDTO();
        dto.setTempId(entity.getTempId());
        dto.setTemperature(entity.getTemperature());
        dto.setRecordedAt(entity.getRecordedAt());
        if (entity.getCoffeeMachine() != null) {
            dto.setCoffeeMachineId(entity.getCoffeeMachine().getCoffeeMachineId());
        }
        return dto;
    }
}

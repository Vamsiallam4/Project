package com.example.coffee.entity;

public enum CoffeeMachineStatus {
    ACTIVE,
    INACTIVE
}

package com.example.coffee.controller;

import com.example.coffee.dto.BranchDTO;
import com.example.coffee.entity.Branch;
import com.example.coffee.service.BranchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/branches")
public class BranchController {
    @Autowired
    private BranchService branchService;

    @PostMapping
    public ResponseEntity<Branch> createBranch(@RequestBody BranchDTO branchDTO) {
        return ResponseEntity.ok(branchService.createBranch(branchDTO));
    }

    @GetMapping("/location/{locationId}")
    public ResponseEntity<List<Branch>> getBranchesByLocation(@PathVariable Long locationId) {
        return ResponseEntity.ok(branchService.getBranchesByLocation(locationId));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Branch> getBranch(@PathVariable Long id) {
        return ResponseEntity.ok(branchService.getBranch(id));
    }
}

package com.example.coffee.entity;

import jakarta.persistence.*;
import lombok.Data;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import java.util.List;

@Data
@Entity
@Table(name = "locations")
public class Location {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @JsonManagedReference
    @OneToMany(mappedBy = "location", cascade = CascadeType.ALL)
    private List<Branch> branches;

    public Location() {
    }
    public Location(String name) {
        this.name = name;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public List<Branch> getBranches() {
        return branches;
    }
    public void setBranches(List<Branch> branches) {
        this.branches = branches;
    }
    public Location(String name, List<Branch> branches) {
        this.name = name;
        this.branches = branches;
    }
    public Location(Long id, String name) {
        this.id = id;
        this.name = name;
    }
    public Location(Long id) {
        this.id = id;
    }
    public Location(Long id, String name, List<Branch> branches) {
        this.id = id;
        this.name = name;
        this.branches = branches;
    }
    public Location(Long id, List<Branch> branches) {
        this.id = id;
        this.branches = branches;
    }
    public Location(List<Branch> branches) {
        this.branches = branches;
    }
}
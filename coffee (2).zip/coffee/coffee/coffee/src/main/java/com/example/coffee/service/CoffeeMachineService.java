package com.example.coffee.service;

import com.example.coffee.entity.CoffeeMachine;
import com.example.coffee.entity.CoffeeMachineStatus;
import com.example.coffee.entity.Branch;
import com.example.coffee.repository.CoffeeMachineRepository;
import com.example.coffee.dto.CoffeeMachineDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CoffeeMachineService {

    @Autowired
    private CoffeeMachineRepository coffeeMachineRepository;

    @Autowired
    private BranchService branchService;

    public CoffeeMachine getCoffeeMachine(Long atmId) {
        return coffeeMachineRepository.findById(atmId)
                .orElseThrow(() -> new RuntimeException("Coffee Machine not found"));
    }

    public CoffeeMachine createCoffeeMachine(CoffeeMachineDTO dto) {
        Branch branch = branchService.getBranch(dto.getBranchId());
        CoffeeMachine machine = new CoffeeMachine();
        machine.setMachineCode(dto.getMachineCode());
        machine.setBranch(branch);
        return coffeeMachineRepository.save(machine);
    }

    public CoffeeMachine toggleStatus(Long coffeeMachineId) {
        CoffeeMachine machine = coffeeMachineRepository.findById(coffeeMachineId)
            .orElseThrow(() -> new RuntimeException("Coffee Machine not found"));
        machine.setStatus(machine.getStatus() == CoffeeMachineStatus.ACTIVE ? 
            CoffeeMachineStatus.INACTIVE : CoffeeMachineStatus.ACTIVE);
        return coffeeMachineRepository.save(machine);
    }
}
package com.example.coffee.controller;

import com.example.coffee.entity.CoffeeMachine;
import com.example.coffee.service.CoffeeMachineService;
import com.example.coffee.dto.CoffeeMachineDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/coffee-machines")
public class CoffeeMachineController {

    @Autowired
    private CoffeeMachineService coffeeMachineService;

    @PostMapping
    public ResponseEntity<CoffeeMachine> createCoffeeMachine(@RequestBody CoffeeMachineDTO dto) {
        return ResponseEntity.ok(coffeeMachineService.createCoffeeMachine(dto));
    }

    @PutMapping("/{id}/toggle-status")
    public ResponseEntity<CoffeeMachine> toggleStatus(@PathVariable("id") Long coffeeMachineId) {
        return ResponseEntity.ok(coffeeMachineService.toggleStatus(coffeeMachineId));
    }
}